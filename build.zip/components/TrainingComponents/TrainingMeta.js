export const Meta = {
    "ui-ux-design-training-in-nepal": [
        { detail: "check", content: "check" },
        { name: "description", content: "UI/UX design training" },
        { name: "title", content: "UI/UX design training" },
        { name: "keywords", content: "UI/UX design training, it courses in nepal" },
        { property: "og:title", content: "UI/UX design training" },
        { property: "og:description", content: "UI/UX design training" },
    ]
}

