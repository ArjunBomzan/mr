const SYLLABUS = [
    {
        subheading: "Flutter Introduction",
        details: [
            "Introduction to JavaScript programming language Technologies around JavaScript. ",
            "Introduction to nodejs."
        ]
    },
    {
        subheading: "Introduction2",
        details: [
            "Introduction to JavaScript programming language Technologies around JavaScript. "
        ]
    }
]

export default SYLLABUS