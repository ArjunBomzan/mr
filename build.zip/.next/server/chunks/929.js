"use strict";
exports.id = 929;
exports.ids = [929];
exports.modules = {

/***/ 5929:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ HeaderComponents_HeaderRight)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react-responsive"
var external_react_responsive_ = __webpack_require__(6666);
var external_react_responsive_default = /*#__PURE__*/__webpack_require__.n(external_react_responsive_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-router-dom"
var external_react_router_dom_ = __webpack_require__(4661);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/HeaderComponents/HeaderTabs.jsx


// import Link from 'next/link';



const HeaderTabs = ()=>{
    const router = (0,router_.useRouter)();
    const pathname = router.pathname.split("/")[1];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col items-center space-y-7 sm:space-y-0 lg:flex-row lg:space-x-5 h-full sm:justify-evenly font-medium text-xl sm:text-lg ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: `nav-button ${pathname == "courses" && "active"}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/courses",
                    children: "Courses"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: `nav-button ${pathname == "+2courses" && "active"}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/+2",
                    children: "After +2 Courses"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: `nav-button ${pathname == "+2courses" && "active"}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/online-admission",
                    children: "Online Admission"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: `nav-button ${pathname == "+2courses" && "active"}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/partners",
                    children: "Placement Partner"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: `nav-button ${pathname == "+2courses" && "active"}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/success-gallery",
                    children: "Success Gallery"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: `nav-button ${pathname == "blogs" && "active"}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/blogs",
                    children: "Blogs"
                })
            })
        ]
    });
};
/* harmony default export */ const HeaderComponents_HeaderTabs = (HeaderTabs);

;// CONCATENATED MODULE: ./components/HeaderComponents/HeaderButtonRight.tsx


const HeaderButtonRight = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: "/contact",
        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
            className: "rounded-lg h-10 px-5 text-md bg-green-500 text-white hover:bg-slate-300 hover:text-black duration-300",
            children: "Contact Us"
        })
    });
};
/* harmony default export */ const HeaderComponents_HeaderButtonRight = (HeaderButtonRight);

;// CONCATENATED MODULE: ./components/HeaderComponents/Dropdown.tsx


const Dropdown = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full h-2/3 bg-white fixed z-[10] top-[77px] m-0 right-0",
        children: /*#__PURE__*/ jsx_runtime_.jsx(HeaderComponents_HeaderTabs, {})
    });
};
/* harmony default export */ const HeaderComponents_Dropdown = (Dropdown);

;// CONCATENATED MODULE: ./components/HeaderComponents/Hamburger.tsx



const Hamburger = ()=>{
    const [expanded, setExpanded] = (0,external_react_.useState)(false);
    const toggleExpanded = ()=>{
        setExpanded((oldState)=>!oldState);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            !expanded && /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                onClick: toggleExpanded,
                className: "h-8 w-8 cursor-pointer",
                viewBox: "0 0 20 20",
                fill: "currentColor",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    fillRule: "evenodd",
                    d: "M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z",
                    clipRule: "evenodd"
                })
            }),
            expanded && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        onClick: toggleExpanded,
                        className: "h-8 w-8 cursor-pointer",
                        viewBox: "0 0 20 20",
                        fill: "currentColor",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            "fill-rule": "evenodd",
                            d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                            clipRule: "evenodd"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(HeaderComponents_Dropdown, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const HeaderComponents_Hamburger = (Hamburger);

;// CONCATENATED MODULE: ./components/HeaderComponents/HeaderRight.tsx





const HeaderRight = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-row space-x-8 items-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_responsive_default()), {
                minWidth: 1101,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(HeaderComponents_HeaderTabs, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(HeaderComponents_HeaderButtonRight, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_responsive_default()), {
                maxWidth: 1100,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(HeaderComponents_Hamburger, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx((external_react_responsive_default()), {
                        minWidth: 768,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(HeaderComponents_HeaderButtonRight, {})
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const HeaderComponents_HeaderRight = (HeaderRight);


/***/ })

};
;