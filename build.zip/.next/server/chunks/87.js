"use strict";
exports.id = 87;
exports.ids = [87];
exports.modules = {

/***/ 9721:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);



const BlogCard = ({ thumbnail , title , blurb , md , url , imgAlt  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const type = router.pathname.split("/")[1];
    console.log(type == "tech-services" || type == "services");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        // href={`/tech-services/${url}`}
        href: `/${type == "tech-services" || type == "services" ? "tech-services" : "blogs"}/${url}`,
        // onClick={handleOnClick}
        className: "cursor-pointer h-[450px] blog-container image-box bg-white flex flex-col rounded-md duration-500",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "image-box max-h-56 h-56",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: thumbnail,
                    alt: imgAlt,
                    className: "h-56 object-cover bg-cover"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col p-6 gap-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        className: " text-neutral-600 font-bold text-xl ",
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: " text-neutral-700 text-base ",
                        children: blurb
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: " text-green-500 text-base underline underline-offset-4 font-normal cursor-pointer w-max decoration-current duration-200 hover:decoration-white",
                        children: "Read Now"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlogCard);


/***/ }),

/***/ 5730:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ BlogsComponents_BlogsBanner)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./assets/homePage/blog-splash.jpg
/* harmony default export */ const blog_splash = ({"src":"/_next/static/media/blog-splash.51e0b067.jpg","height":1280,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABQEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAng//xAAaEAACAgMAAAAAAAAAAAAAAAACAwQRAAUh/9oACAEBAAE/AFbF8SCxI0SX2BrPo5//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAXEQADAQAAAAAAAAAAAAAAAAAAASEx/9oACAEDAQE/AHdP/9k=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./components/BlogsComponents/BlogsBanner.jsx


const BlogsBanner = (props)=>{
    console.log(props);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            backgroundImage: props?.banner ? `url(${props?.banner})` : `url(${blog_splash.src})`
        },
        className: "w-full bg-blogs relative",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-full h-full py-28 flex flex-col justify-center items-center bg-light-mask text-white",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: " text-4xl sm:text-6xl w-ma font-bold text-center",
                    children: props?.title
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "text-gray-200 text-start absolute bottom-0 left-0 m-3 mx-5 flex flex-col",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: props?.date?.split("T")[0]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: props?.auth_name
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const BlogsComponents_BlogsBanner = (BlogsBanner);


/***/ }),

/***/ 8232:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Loader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/loading.svg
/* harmony default export */ const loading = ({"src":"/_next/static/media/loading.46db16e8.svg","height":51,"width":51});
;// CONCATENATED MODULE: ./components/Loader.jsx



const Loader = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "h-screen w-screen flex items-center justify-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: loading
        })
    });
};
/* harmony default export */ const components_Loader = (Loader);


/***/ })

};
;