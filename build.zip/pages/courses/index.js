import React from 'react';
import Trainings from "../../components/TrainingComponents/Trainings";

const courses = () => {
    return (
        <>
            <Trainings />
        </>
    )
}

export default courses