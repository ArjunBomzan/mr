import AboutUs from '../components/AboutUsComponents/AboutUs'

export default function Home() {
    return (
        <AboutUs />
    )
}
