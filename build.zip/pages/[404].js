import NotFound from "../components/NotFound"
export default function notFound() {
    return (<NotFound />)
}