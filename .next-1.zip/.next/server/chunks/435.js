"use strict";
exports.id = 435;
exports.ids = [435];
exports.modules = {

/***/ 8435:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ HeaderComponents_Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/HeaderComponents/HeaderLeft.tsx + 1 modules
var HeaderLeft = __webpack_require__(5569);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/HeaderComponents/HeaderTabs.jsx



const HeaderTabs = ()=>{
    const router = (0,router_.useRouter)();
    const pathname = router.pathname.split("/")[1];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
        className: "navbar-nav flex items-center flex-col pl-0 list-style-none mr-auto lg:mr-0 lg:items-center justify-start font-medium text-[0.82rem] xl:text-lg text-fade transition duration-150 ease-in-out mt-7 sm:mt-0",
        style: {
            animationDuration: "0.2s"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: "nav-item p-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/courses",
                    className: `nav-button ${pathname == "courses" && "active"} `,
                    children: "Courses"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: "nav-item p-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/after+2-courses",
                    className: `nav-button ${pathname == "after+2-courses" && "active"}`,
                    children: "After +2 Courses"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: "nav-item p-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/online-admission",
                    className: `nav-button ${pathname == "online-admission" && "active"}`,
                    children: "Online Admission"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: "nav-item p-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/placement-partner",
                    className: `nav-button ${pathname == "placement-partner" && "active"}`,
                    children: "Placement Partner"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: "nav-item p-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/success-gallery",
                    className: `nav-button ${pathname == "success-gallery" && "active"}`,
                    children: "Success Gallery"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: "nav-item p-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/blogs",
                    className: `nav-button ${pathname == "blogs" && "active"}`,
                    children: "Blogs"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: "nav-item lg:py-0 p-2 pr-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/contact-us",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "rounded-lg h-10 px-5 text-md bg-green-500 text-white hover:bg-slate-300 hover:text-black duration-300",
                        children: "Contact Us"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const HeaderComponents_HeaderTabs = (HeaderTabs);

;// CONCATENATED MODULE: ./components/HeaderComponents/HeaderTailwind.jsx
// import dynamic from 'next/dynamic'



const HeaderTailwind = ()=>{
    // const HeaderTabs = dynamic(
    //     () => import('./HeaderTabs'),
    //     { ssr: false }
    // )
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        id: "navbar--sticky",
        className: "sticky-top bg-white w-full flex flex-wrap items-center justify-between py-4 shadow-lg navbar navbar-expand-lg navbar-light pt-4 pb-4 px-6 sm:px-12 md:px-14 lg:px-18 ",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-fluid w-full flex flex-wrap items-center justify-between",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(HeaderLeft/* default */.Z, {}),
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: " navbar-toggler text-gray-500 border-0 hover:shadow-none hover:no-underline py-2 px-2.5 -mx-2.5 bg-transparent focus:outline-none focus:ring-0 focus:shadow-none focus:no-underline ",
                    type: "button",
                    "data-bs-toggle": "collapse",
                    "data-bs-target": "#navbarSupportedContent",
                    "aria-controls": "navbarSupportedContent",
                    "aria-expanded": "false",
                    "aria-label": "Toggle navigation",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        "aria-hidden": "true",
                        focusable: "false",
                        "data-prefix": "fas",
                        "data-icon": "bars",
                        className: "w-6",
                        role: "img",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 448 512",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            fill: "currentColor",
                            d: "M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "collapse navbar-collapse flex-grow items-center justify-end",
                    id: "navbarSupportedContent",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(HeaderComponents_HeaderTabs, {})
                })
            ]
        })
    });
};
/* harmony default export */ const HeaderComponents_HeaderTailwind = (HeaderTailwind);

// EXTERNAL MODULE: ./components/HeaderComponents/SocialLinks.jsx
var SocialLinks = __webpack_require__(1924);
;// CONCATENATED MODULE: ./components/HeaderComponents/Header.jsx



const Header = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                id: "navbar",
                className: " bg-green-500 top-0 flex flex-row justify-center sm:justify-between items-center text-white px-6 sm:px-12 md:px-14 lg:px-18 ",
                style: {
                    fontSize: "0.9rem"
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-md font-bold whitespace-nowrap hidden sm:block ",
                        children: [
                            "Contact: ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "font-bold",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "tel:9843217125",
                                    children: "+977 9843217125"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "py-2 flex gap-4 sm:gap-6 header-socials justify-end sm:justify-end w-full",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SocialLinks/* default */.Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(HeaderComponents_HeaderTailwind, {
                className: "sticky-top"
            })
        ]
    });
};
/* harmony default export */ const HeaderComponents_Header = (Header);


/***/ })

};
;