"use strict";
exports.id = 882;
exports.ids = [882];
exports.modules = {

/***/ 882:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2494);
/* harmony import */ var _Loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8232);
/* harmony import */ var _BlogCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9721);
/* harmony import */ var _BlogsBanner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5730);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_3__]);
_pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const Blogs = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const [blogs, setBlogs] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const type = router.pathname?.split("/")[1];
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setBlogs();
        {
            type == "blogs" && (0,_pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_3__/* .singleBlogApi */ .zl)({
                setBlogs
            });
            type == "tech-services" && (0,_pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_3__/* .techServicesApi */ .bX)({
                setBlogs
            });
            type == "services" && (0,_pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_3__/* .techServicesApi */ .bX)({
                setBlogs
            });
        }
    }, [
        router.pathname
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: blogs ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
            className: `h-max w-full`,
            children: [
                type == "blogs" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BlogsBanner__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    title: "Blogs",
                    desc: "Got a moment to read our latest blogs?"
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "w-full text-center text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold mt-12 mb-10",
                    children: "Tech services we provide"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: "grid gap-4 grid-cols-1 sm:grid-cols-2 sm:gap-4 lg:gap-10 lg:grid-cols-3 my-10 lg:px-44 md:px-20 sm:px-2 px-4",
                    children: blogs?.map((blog)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BlogCard__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            title: blog.title,
                            // blurb="Lifting your people and business"
                            blurb: blog.short_desc,
                            thumbnail: blog.img ? blog.img : blog.image,
                            md: "We help you get placed in top companies.",
                            url: blog.slug,
                            imgAlt: blog.title
                        }, blog.slug);
                    })
                })
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loader__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Blogs);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;