"use strict";
exports.id = 427;
exports.ids = [427];
exports.modules = {

/***/ 5427:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3135);
/* harmony import */ var rehype_raw__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1871);
/* harmony import */ var remark_gfm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6809);
/* harmony import */ var _pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2494);
/* harmony import */ var _Loader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8232);
/* harmony import */ var _BlogsBanner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5730);
/* harmony import */ var _RelatedBlogs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9908);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_3__, rehype_raw__WEBPACK_IMPORTED_MODULE_4__, remark_gfm__WEBPACK_IMPORTED_MODULE_5__, _pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_6__]);
([react_markdown__WEBPACK_IMPORTED_MODULE_3__, rehype_raw__WEBPACK_IMPORTED_MODULE_4__, remark_gfm__WEBPACK_IMPORTED_MODULE_5__, _pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const Blog = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const [blog, setBlog] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [blogs, setBlogs] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [description, setDescription] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { slug  } = router.query;
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setBlogs([]);
        if (router.isReady) {
            const index = blogs.indexOf(slug);
            console.log("index", blogs.indexOf(slug), slug);
            if (index !== -1) blogs.splice(index, 1);
            router.pathname?.split("/")[1] == "blogs" && (0,_pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_6__/* .singleBlogApi */ .zl)({
                setBlog,
                setDescription,
                setBlogs,
                slug
            });
            router.pathname?.split("/")[1] == "tech-services" && (0,_pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_6__/* .techServicesApi */ .bX)({
                setBlog,
                setDescription,
                setBlogs,
                slug
            });
        }
    }, [
        slug,
        router.isReady
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: blog ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "px-0 lg:px-44 pb-20 ",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BlogsBanner__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        banner: blog?.banner,
                        title: blog?.title,
                        auth_name: blog?.auth_name,
                        date: blog?.updated_at
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                    className: "blogs-container bg-white pb-10 px-6 lg:px-0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full flex justify-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("article", {
                            className: "h-full ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                remarkPlugins: [
                                    remark_gfm__WEBPACK_IMPORTED_MODULE_5__["default"]
                                ],
                                rehypePlugins: [
                                    rehype_raw__WEBPACK_IMPORTED_MODULE_4__["default"]
                                ],
                                children: description
                            })
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RelatedBlogs__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    blogs: blogs,
                    slug: slug
                })
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loader__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Blog);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9908:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _BlogCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9721);




const RelatedBlogs = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const type = router.pathname?.split("/")[1];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: " px-6 lg:px-0",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                className: "text-4xl font-bold",
                children: [
                    type == "blogs" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Recent Blogs"
                    }),
                    type == "tech-services" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Other Services"
                    }),
                    type == "services" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Other Services"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "grid gap-8 grid-cols-1 sm:grid-cols-2 sm:gap-4 lg:gap-10 lg:grid-cols-3 my-10",
                children: props?.blogs?.slice(0, 3)?.map((blog)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BlogCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        title: blog.title,
                        // blurb="Lifting your people and business"
                        blurb: blog.short_desc,
                        thumbnail: blog.img ? blog.img : blog.image,
                        url: blog.slug,
                        imgAlt: blog.title
                    }, blog.id);
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RelatedBlogs);


/***/ })

};
;