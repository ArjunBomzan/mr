"use strict";
exports.id = 766;
exports.ids = [766];
exports.modules = {

/***/ 2106:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ HomePageComponents_HomeAboutUs)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./assets/homePage/matrix.jpg
/* harmony default export */ const matrix = ({"src":"/_next/static/media/matrix.29cadff8.jpg","height":2092,"width":4304,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQP/2gAMAwEAAhADEAAAAJwM/wD/xAAbEAABBAMAAAAAAAAAAAAAAAACAQMEBQATIf/aAAgBAQABPwCTdSgqGmdTCggkvRz/xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAgBAgEBPwCv/8QAFhEAAwAAAAAAAAAAAAAAAAAAAAER/9oACAEDAQE/AIj/2Q==","blurWidth":8,"blurHeight":4});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/HomePageComponents/HomeAboutUs.tsx




const HomeAboutUs = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: " space-y-12 h-max bg-neutral-100",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " py-16 sm:py-16 lg:space-y-0 lg:mx-44 md:mx-20 sm:mx-16 mx-2 lg:flex-row flex flex-col px-4 gap-8",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col w-full lg:w-1/2 space-y-9 ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "w-5/6 text-xl font-bold sm:text-2xl md:text-2xl lg:text-3xl xl:text-4xl",
                            children: "About Us"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: "text-justify about-us",
                            children: [
                                "Mind Risers is a parent company of ",
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "https://jobrisers.com/",
                                    children: "jobrisers.com"
                                }),
                                ",  ",
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "https://tummytruck.com.np/",
                                    children: "tummytruck.com.np"
                                }),
                                ", ",
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "https://digitalpalika.org/",
                                    children: "digitalpalika.org"
                                }),
                                " , mind risers software development company, and the training institute. We are the only company in Nepal where we guarantee paid internship and job placement after the course is completed in our software development and digital marketing company. What we believe is practical knowledge can be delivered only if the institution continuously does research and development in the same place."
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: "#why-us-container",
                            scroll: false,
                            className: "items-center flex flex-row space-x-2 px-4 py-3 mt-8 text-white duration-500 bg-green-500 rounded-md w-max fill-white hover:fill-black hover:text-black hover:bg-slate-300",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "font-semibold text-md",
                                    children: "Discover More"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    className: "w-6 h-6",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    stroke: "currentColor",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "2",
                                        d: "M13 9l3 3m0 0l-3 3m3-3H8m13 0a9 9 0 11-18 0 9 9 0 0118 0z"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-full lg:w-1/2",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        style: {
                            marginTop: "60px"
                        },
                        src: matrix,
                        alt: "Services",
                        className: "object-cover w-full rounded-md"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const HomePageComponents_HomeAboutUs = (HomeAboutUs);


/***/ }),

/***/ 37:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ProgressBar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7627);
/* harmony import */ var _Statistic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5435);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ProgressBar__WEBPACK_IMPORTED_MODULE_1__, _Statistic__WEBPACK_IMPORTED_MODULE_2__]);
([_ProgressBar__WEBPACK_IMPORTED_MODULE_1__, _Statistic__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const Mission = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "flex flex-col w-full px-5 py-20 space-y-24 h-max sm:py-32 sm:px-32 lg:px-44",
        id: "why-us-container",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col justify-between w-full md:flex-row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col w-full mb-16 ml-1 space-y-10 md:ml-0 md:mb-0 md:w-1/2 md:mr-16 "
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full space-y-8 md:w-1/2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: " text-3xl font-bold md:text-4xl",
                                children: "WHY US?"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-justify",
                                children: "Our technological development competence is progressive and on track with Next-Gen Tech Applications. MindRisers is the first choice of our clients and students due to its outstanding and unbeatable outcomes. Our clients say that MindRisers is the best IT service providing and digital marketing agency in Nepal. Allow us to plan, build, and improve your tech products so that you can concentrate on your core market. You can rely on us for your digital needs as we have a group consisting of innovative thinkers, fast engineers, vigilant program managers, and active Web Marketers."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-row justify-between w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Statistic__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            className: "h-9 w-9 ",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: "1",
                                d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                            })
                        }),
                        statNum: 5,
                        text: "YEARS"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Statistic__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            className: "h-9 w-9",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: "1",
                                d: "M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"
                            })
                        }),
                        statNum: 12,
                        text: "COURSES"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Statistic__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            className: "h-9 w-9",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: "1",
                                d: "M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                            })
                        }),
                        statNum: 237,
                        text: "STUDENTS"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Statistic__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            className: "h-9 w-9",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: "1",
                                d: "M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
                            })
                        }),
                        statNum: 477,
                        text: "PLACEMENTS"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Mission);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7627:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_intersection_observer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4009);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_intersection_observer__WEBPACK_IMPORTED_MODULE_1__]);
react_intersection_observer__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const ProgressBar = ({ value , label  })=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ _jsx("p", {
                className: "mb-3 text-sm font-bold tracking-wide text-neutral-600 ",
                children: label
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "flex flex-row w-full h-1 bg-neutral-800",
                children: [
                    /*#__PURE__*/ _jsx(InView, {
                        triggerOnce: true,
                        children: ({ inView , ref , entry  })=>/*#__PURE__*/ _jsx("div", {
                                className: `h-full bg-green-400 transition-all progress-bar text-neutral-600`,
                                style: {
                                    width: inView ? `${value}%` : 0
                                },
                                ref: ref
                            })
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "w-[4px] bg-green-400 h-4 translate-y-[-12px]"
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "bg-green-400 w-[32px] h-[32px] rounded-[50%] z-20 translate-x-[-18px] translate-y-[-36px] font-bold text-xs flex justify-center items-center",
                        children: `${value}%`
                    })
                ]
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ProgressBar)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5435:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_countup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(609);
/* harmony import */ var react_countup__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_countup__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4009);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__]);
react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const Statistic = ({ icon , statNum , text  })=>{
    const [active, setIsActive] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col items-center justify-center w-max mission",
        children: [
            icon,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: "pt-2 pb-2 text-3xl font-bold md:text-5xl lg:text-6xl xl:text-7xl md:pt-0 md:pb-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__.InView, {
                    triggerOnce: true,
                    children: ({ inView , ref , entry  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            ref: ref,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_countup__WEBPACK_IMPORTED_MODULE_2___default()), {
                                end: inView ? statNum : 0,
                                redraw: false,
                                duration: 1,
                                onEnd: ()=>setIsActive(false),
                                active: active,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    ref: statNum
                                })
                            })
                        })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "text-xs md:text-md",
                children: text
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Statistic);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;