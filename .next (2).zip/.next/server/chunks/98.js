exports.id = 98;
exports.ids = [98];
exports.modules = {

/***/ 8536:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/pentagram.690500eb.jpg","height":438,"width":438,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAqgP/xAAdEAABAgcAAAAAAAAAAAAAAAARABIBAwQTQmGh/9oACAEBAAE/AIzKq+3FwLdEA9X/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 3056:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/prabhu-pay.afcc634f.png","height":1080,"width":1080,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAyUlEQVR42hXNOW7CQBQG4P/ZEysgOYkbCxwnUiB1pKTIYahYCgqEuAD3gDshtoICKIAGzCZ2s3hmHuK7wEddOBobAhgPlPhSwYgAEa+WLS+pjkdW+jmdUoeD3O2j5UKYth2t12q7g1Lh5Sxnc+El9ClEJ5luAd3f//1gGE6nvWy+ATQBg1wHgFMpPRop3UKOAPPnz4BUDNyCIPbhx9/962LJAEeS2v43CVOP+06tbr6+rDJFvNkUs6jtpcAM60lOBgwI95MMg7W+A4SxVmdy6AP9AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 3793:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/realpath.ee441089.jpg","height":305,"width":305,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAAH/2gAMAwEAAhADEAAAAK0I/8QAGxAAAgEFAAAAAAAAAAAAAAAAAQIABBExMuH/2gAIAQEAAT8AD1CEo6s5vsMcn//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 7777:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/tummy-truck.833ec43e.png","height":2000,"width":2000,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA2klEQVR42mPAB3brWTAx7BA3S97MYFGymcG0ZyODZcY2LiuPPeZWWXutbfXBqg56mu09m2Vx50KhxbNLZZb/j0VYPFvG4K63U8U2HazgaJjl1PMFlu8ulVo9Pptjv+aAq93RM5lmNUdDzNduZLCRYziXazHtdqfF//sTLP/eaDR/e7PF4s+DiRb/r1Sa/t/KYL2L4YCLWfXJRPP7Z9LNLx0NM/5/2M/kzUF38+OHfKy791g6ZaC4eiuDWdUOBesVsxjK2FEk/n9nYISxz1cmgiUPeRmw7dKyZgYAwFBWT3DQfQEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 9316:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/vianet.bdb7fdc5.png","height":740,"width":800,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAw0lEQVR42mN4I63CyAAEj2SUdRiAwFdOoW+HrFIzAxAskFVkYXgjrczCAAQfpVX6zssotzDIy0/9L6UqwAADD2SUmRmAAChofUhW6T9QQSgDEDjKKbAC2YwMMPCf0Zjxvoyy5V5ZJSYGFGDKwHhYVkUrUF4RYqy8HC+DgiwXg4IcD9AEGYYWOUWvBjnFsDY5Re8qOYWkHjlFx2o5hXAgjqgC0gzbZJWCj8oquRyWVXIDGu9zWkbJAch2PyCr5HVKRskBAF0KLA3Bokf6AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 1098:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3015);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2996);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3877);
/* harmony import */ var _assets_partners_prabhu_pay_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3056);
/* harmony import */ var _assets_partners_pentagram_jpg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8536);
/* harmony import */ var _assets_partners_realpath_jpg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3793);
/* harmony import */ var _assets_partners_tummy_truck_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7777);
/* harmony import */ var _assets_partners_vianet_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9316);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6666);
/* harmony import */ var react_responsive__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_responsive__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_1__, swiper__WEBPACK_IMPORTED_MODULE_5__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_1__, swiper__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const Partner = ({ image , name  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_12___default()), {
        src: image,
        alt: name,
        className: "w-32 h-32 mx-auto 2xl:h-32 2xl:w-32"
    });
};
const Partners = ()=>{
    const useTwo = (0,react_responsive__WEBPACK_IMPORTED_MODULE_11__.useMediaQuery)({
        query: "(min-width: 640px)"
    });
    const useThree = (0,react_responsive__WEBPACK_IMPORTED_MODULE_11__.useMediaQuery)({
        query: "(min-width: 1024px)"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "flex flex-col px-5 py-20 space-y-12 bg-neutral-100 h-max sm:pt-24 sm:px-10 md:px-20 lg:px-40 xl:px-48",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "w-full mb-5 text-2xl font-bold text-center sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl",
                        children: "We strive to work with the best"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "w-full text-center",
                        children: "We have worked with successful companies, who have nothing but good things to say about us."
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_1__.Swiper, {
                    slidesPerView: useThree ? 3 : useTwo ? 2 : 1,
                    spaceBetween: 30,
                    slidesPerGroup: 1,
                    loop: true,
                    speed: 800,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: false
                    },
                    loopFillGroupWithBlank: false,
                    // pagination={{
                    //   clickable: false,
                    // }}
                    navigation: true,
                    modules: [
                        swiper__WEBPACK_IMPORTED_MODULE_5__.Navigation,
                        swiper__WEBPACK_IMPORTED_MODULE_5__.Autoplay
                    ],
                    className: "mySwiper",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.SwiperSlide, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Partner, {
                                image: _assets_partners_prabhu_pay_png__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                                name: "PrabhuPay"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.SwiperSlide, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Partner, {
                                image: _assets_partners_tummy_truck_png__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                                name: "TummyTruck"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.SwiperSlide, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Partner, {
                                image: _assets_partners_vianet_png__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                                name: "Vianet"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.SwiperSlide, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Partner, {
                                image: _assets_partners_pentagram_jpg__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                                name: "Pentagram"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.SwiperSlide, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Partner, {
                                image: _assets_partners_realpath_jpg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
                                name: "realpath"
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Partners);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9176:
/***/ (() => {



/***/ }),

/***/ 2996:
/***/ (() => {



/***/ }),

/***/ 8722:
/***/ (() => {



/***/ })

};
;