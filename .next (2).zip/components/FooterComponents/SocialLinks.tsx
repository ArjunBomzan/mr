const SocialLinks = () => {
  return (
    <div>
      Social Links
    </div>
  )
}

export default SocialLinks
