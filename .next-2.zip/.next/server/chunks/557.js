"use strict";
exports.id = 557;
exports.ids = [557];
exports.modules = {

/***/ 8232:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Loader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/loading.svg
/* harmony default export */ const loading = ({"src":"/_next/static/media/loading.5814c667.svg","height":51,"width":51});
;// CONCATENATED MODULE: ./components/Loader.jsx



const Loader = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "h-screen w-screen flex items-center justify-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: loading,
            alt: "spinner"
        })
    });
};
/* harmony default export */ const components_Loader = (Loader);


/***/ }),

/***/ 9121:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8232);
/* harmony import */ var _TrainingCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5191);




const Trainings = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const pathname = router.pathname.split("/")[1];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                className: "w-full text-2xl font-bold text-center md:text-3xl lg:text-4xl xl:text-5xl pt-10",
                children: [
                    pathname == "courses" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Courses"
                    }),
                    pathname == "after+2-courses" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "After +2 Courses"
                    })
                ]
            }),
            props?.courses ? // <section className={`bg-white flex flex-col py-10 px-6 sm:px-12 md:px-14 lg:px-18 `}>
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: `bg-white flex flex-col pb-10 lg:px-44 md:px-20 sm:px-16 `,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "grid grid-cols-2 gap-8 sm:grid-cols-3 lg:grid-cols-4 mt-6 ",
                    children: props?.courses?.map((course)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TrainingCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            course: course
                        }, course.id);
                    })
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Trainings);


/***/ })

};
;