"use strict";
exports.id = 858;
exports.ids = [858];
exports.modules = {

/***/ 4858:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ BlogShare)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/social/iconmonstr-facebook-4-240.png
/* harmony default export */ const iconmonstr_facebook_4_240 = ({"src":"/_next/static/media/iconmonstr-facebook-4-240.11c27936.png","height":240,"width":240,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAV1BMVEU5VpI4VZE5VpI5VpI5VpI5VpI4VZE5VpI5VpI5VpI5VpI5VpI5VpI5VpI4VZE5VpI5VpI5VpI4VZE5VpI5VpI5VpI4VZE5VpI5VpI4VZE4VZE5VpI4VZFSmeIPAAAAG3RSTlMADigpKj09VVqJl6PAwcHCw9Td4e3w9/j6/P4ZtQeiAAAAQklEQVR42hXKSRKAIBADwOjgDuKCOpr8/50W524gJHIzwIrORZchi0N7K+HR3oyUwz/2E1+v1M1Urnk9VAwIkYwBP5VhBCnGsBziAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/social/iconmonstr-twitter-4-240.png
/* harmony default export */ const iconmonstr_twitter_4_240 = ({"src":"/_next/static/media/iconmonstr-twitter-4-240.4518b63e.png","height":240,"width":240,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAclBMVEUcnOoZmuseneohn+oeneodnOodnOodnOocnOocnOocnOodnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOocnOobm+scnOocnOscnOobm+utioITAAAAI3RSTlMAAAoLISgpKjtHTVBziqG+v8DFxsfI3eDj7O/w8/f4+fv7/T2dG6IAAABESURBVHjaBUAHFkAwDP1GU5vYlFjJ/a/oAdTd0jqAgj1mh0Ovg9ZlmPBKWsTRojitAnIV8Nck2WwM2mVV2zxAo17s8QOxWwTi+mXGiAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/social/iconmonstr-linkedin-4-240.png
/* harmony default export */ const iconmonstr_linkedin_4_240 = ({"src":"/_next/static/media/iconmonstr-linkedin-4-240.e0135874.png","height":240,"width":240,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAWlBMVEUCdLADdLADdLABc68DdLADdLACdLACdLABc68CdLACdLACdLABc7ACdLACdLACdLACdLACdLACdLACdLACdLACdLACdLACdLACdLACdLACdLABc68CdLABc6/vBFZiAAAAHHRSTlMAKSoqYmdse6Wtu8DAwcLEztDe4O3u9vj5+vv7TCtaKgAAAENJREFUeNoNy8cBgDAMBMGTyQibKES6/ttE+9rPACnfTxFAjHxpAuW88mOBc+zagY6TfdXUMcpt2hdmpIORBUvqlwp+liMEGo7Ck0MAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/BlogsComponents/BlogShare.jsx






function BlogShare() {
    let current_url = window.location.href;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "text-center text-lg font-bold mb-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: "Like this Post? Share it with your friends !"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "flex justify-center gap-3 mt-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: `https://www.facebook.com/sharer/sharer.php?u=${current_url}`,
                            target: "_blank",
                            rel: "noreferrer",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: iconmonstr_facebook_4_240,
                                height: 40,
                                width: 40,
                                alt: "facebook-icon"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: `https://twitter.com/intent/tweet?url=${current_url}`,
                            target: "_blank",
                            rel: "noreferrer",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: iconmonstr_twitter_4_240,
                                height: 40,
                                width: 40,
                                alt: "twitter-icon"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: `https://www.linkedin.com/shareArticle?mini=true&url=${current_url}`,
                            target: "_blank",
                            rel: "noreferrer",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: iconmonstr_linkedin_4_240,
                                height: 40,
                                width: 40,
                                alt: "linkedin-icon"
                            })
                        })
                    })
                ]
            })
        ]
    });
}


/***/ })

};
;