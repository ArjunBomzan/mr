exports.id = 672;
exports.ids = [672];
exports.modules = {

/***/ 523:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3877);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper_css_free_mode__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9241);
/* harmony import */ var swiper_css_free_mode__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_free_mode__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2996);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3015);
/* harmony import */ var _pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2494);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ScreenSize__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(728);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper__WEBPACK_IMPORTED_MODULE_1__, swiper_react__WEBPACK_IMPORTED_MODULE_5__, _pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_6__]);
([swiper__WEBPACK_IMPORTED_MODULE_1__, swiper_react__WEBPACK_IMPORTED_MODULE_5__, _pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const HomeSuccessStories = (props)=>{
    // const [success_stories_api_data, setSuccessStories] = useState(initialState);
    // useEffect(() =>{
    // },[])
    const size = (0,_ScreenSize__WEBPACK_IMPORTED_MODULE_9__/* .useWindowSize */ .i)({
        useEffect: react__WEBPACK_IMPORTED_MODULE_7__.useEffect,
        useState: react__WEBPACK_IMPORTED_MODULE_7__.useState
    });
    // const [successStoreis, setSuccessStories] = useState(props.successStoreis);
    // useEffect(() => {
    //     if (!successStoreis) {
    //         homeSuccessStoriesApi({ setSuccessStories })
    //     }
    // }, []);
    const successStoreis = props.successStoreis;
    const Card = ({ title , content , img  })=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "flex justify-center w-full bg-white rounded-lg shadow-lg card-shadow",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "block w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                        height: 450,
                        width: 450,
                        src: img,
                        style: {
                            height: "200px",
                            width: "100%",
                            objectFit: "cover"
                        },
                        className: "training-card-img-div",
                        alt: title
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "p-4",
                        style: {
                            height: "130px"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-gray-900 text-xl font-medium mb-2",
                                children: title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-gray-700 text-base line-clamp-3",
                                children: content
                            })
                        ]
                    })
                ]
            })
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${props.in_training_page ? "" : "py-8 lg:px-44 md:px-20 px-2 bg-neutral-100"}`,
        id: "success_stories",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: `${props.in_training_page ? "mt-10 font-bold text-3xl" : "font-bold text-3xl"} `,
                children: "Success Stories"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_5__.Swiper, {
                slidesPerView: size.width > 1500 ? 4 : size.width > 1200 ? 3 : size.width > 600 ? 2.3 : 1.3,
                spaceBetween: 35,
                freeMode: true,
                pagination: {
                    clickable: true
                },
                modules: [
                    swiper__WEBPACK_IMPORTED_MODULE_1__.FreeMode,
                    swiper__WEBPACK_IMPORTED_MODULE_1__.Pagination,
                    swiper__WEBPACK_IMPORTED_MODULE_1__.Autoplay,
                    swiper__WEBPACK_IMPORTED_MODULE_1__.Navigation
                ],
                loop: false,
                autoplay: {
                    delay: 200000,
                    disableOnInteraction: false
                },
                className: "!-mx-2 md:!mx-0",
                children: successStoreis?.map((successStory)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_5__.SwiperSlide, {
                        className: "mb-16 mt-10 mx-2 md:mx-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Card, {
                            title: successStory.title,
                            content: successStory.content,
                            img: successStory.image
                        })
                    }, successStory.id);
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeSuccessStories);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9241:
/***/ (() => {



/***/ }),

/***/ 2996:
/***/ (() => {



/***/ }),

/***/ 8722:
/***/ (() => {



/***/ })

};
;