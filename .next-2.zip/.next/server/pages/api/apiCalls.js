"use strict";
(() => {
var exports = {};
exports.id = 866;
exports.ids = [866];
exports.modules = {

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6014:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdmissionFormApi": () => (/* binding */ AdmissionFormApi),
/* harmony export */   "ContactListApi": () => (/* binding */ ContactListApi),
/* harmony export */   "DropDownOptions": () => (/* binding */ DropDownOptions),
/* harmony export */   "coursesApi": () => (/* binding */ coursesApi),
/* harmony export */   "coursesCombinesApi": () => (/* binding */ coursesCombinesApi),
/* harmony export */   "galleriesApi": () => (/* binding */ galleriesApi),
/* harmony export */   "homeSuccessStoriesApi": () => (/* binding */ homeSuccessStoriesApi),
/* harmony export */   "publicRequest": () => (/* binding */ publicRequest),
/* harmony export */   "singleBlogApi": () => (/* binding */ singleBlogApi),
/* harmony export */   "techServicesApi": () => (/* binding */ techServicesApi)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// import Swal from "sweetalert2";

const publicRequest = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "https://mindrisers.com.np/blog/api/v1/"
});
async function coursesApi(props) {
    await publicRequest.get(`course/?category=${props.ApiType ? props.ApiType : ""}`).then((res)=>{
        props?.setCourses(res.data);
    }).catch((err)=>console.log(err));
}
async function galleriesApi(props) {
    await publicRequest.get("gallery/").then((res)=>{
        props?.setGalleries(res.data);
    }).catch((err)=>console.log(err));
}
async function homeSuccessStoriesApi(props) {
    await publicRequest.get("successstoryhome/").then((res)=>{
        props?.setSuccessStories(res.data);
    }).catch((err)=>console.log(err));
}
async function singleBlogApi(props) {
    await publicRequest.get(`singleblog/?search=${props?.slug}`).then((res)=>{
        props?.setDescription(res.data[0].description);
        props?.setBlog(res.data[0]);
    }).catch((err)=>console.log(err));
    await publicRequest.get(`singleblog/`).then((res)=>{
        props?.setBlogs(res.data);
    }).catch((err)=>console.log(err));
}
async function techServicesApi(props) {
    await publicRequest.get(`tech/?search=${props?.slug}`).then((res)=>{
        props?.setDescription(res.data[0].description);
        props?.setBlog(res.data[0]);
    }).catch((err)=>console.log(err));
    await publicRequest.get(`tech/`).then((res)=>{
        props?.setBlogs(res.data);
    }).catch((err)=>console.log(err));
}
async function coursesCombinesApi(props) {
    await publicRequest.get(`coursecombine/${props?.slug}/`).then((res)=>{
        props?.setCourse(res.data);
    }).catch((err)=>console.log(err));
}
async function ContactListApi(props) {
    publicRequest.post("contact/list/", props.data).then((res)=>{
        props.setSubmiting(false);
        if (res.status == 200) {
            // Swal.fire({
            //     icon: 'success',
            //     title: 'Thank you',
            //     footer: '<a href="/">Home Page</a>',
            //     html: 'We will get back to you soon.',
            //     confirmButtonColor: '#3085d6',
            //     showCloseButton: true,
            //     focusConfirm: false,
            //     confirmButtonText:
            //         '<i className="fa fa-thumbs-up"></i> View Courses!',
            //     confirmButtonAriaLabel: 'Thumbs up, great!',
            // }).then((result) => {
            //     result.isConfirmed && props?.router.push("/courses");
            // })
            let modal = document.getElementById("admission-modal");
            if (modal) {
                modal.classList.add("active");
            }
            props?.reset();
        }
    }).catch((err)=>{
        props.setSubmiting(false);
        console.log(err);
    });
}
async function AdmissionFormApi(props) {
    publicRequest.post("applicationform/", props.data).then((res)=>{
        props.setSubmiting(false);
        if (res.status == 201) {
            // Swal.fire({
            //     icon: 'success',
            //     title: 'Thank you',
            //     footer: '<a href="/">Home Page</a>',
            //     html: 'We will get back to you soon.',
            //     confirmButtonColor: '#3085d6',
            //     showCloseButton: true,
            //     focusConfirm: false,
            //     confirmButtonText:
            //         '<i className="fa fa-thumbs-up"></i> View Courses!',
            //     confirmButtonAriaLabel: 'Thumbs up, great!',
            // }).then((result) => {
            //     result.isConfirmed && props?.router.push("/courses");
            // })
            let modal = document.getElementById("admission-modal");
            if (modal) {
                modal.classList.add("active");
            }
            props?.reset();
        }
    }).catch((err)=>{
        props.setSubmiting(false);
        console.log(err);
    });
}
async function DropDownOptions(props) {
    props?.setCourse && publicRequest.get("course/").then((res)=>{
        props?.setCourse(res.data);
    }).catch((err)=>{
        console.log(err);
    });
    props?.setSchedule && publicRequest.get("shedule/").then((res)=>{
        props?.setSchedule(res.data);
    }).catch((err)=>{
        console.log(err);
    });
    props?.setQualification && publicRequest.get("qualification/").then((res)=>{
        props?.setQualification(res.data);
    }).catch((err)=>{
        console.log(err);
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6014));
module.exports = __webpack_exports__;

})();