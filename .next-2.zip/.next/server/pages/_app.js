(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5176:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/accordion.scss
var accordion = __webpack_require__(3790);
// EXTERNAL MODULE: ./styles/animations.css
var animations = __webpack_require__(2675);
// EXTERNAL MODULE: ./styles/index.css
var styles = __webpack_require__(9517);
// EXTERNAL MODULE: ./styles/training.css
var training = __webpack_require__(8089);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
;// CONCATENATED MODULE: ./assets/Admission/checked.webp
/* harmony default export */ const checked = ({"src":"/_next/static/media/checked.8495d256.webp","height":240,"width":240,"blurDataURL":"data:image/webp;base64,UklGRo4AAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSD8AAAABYFTbtpIz+hkYuRbgLWJQhwI6pIO7Q9SICOTp+1+QJwTtlMdDkcR7g0FVMzQ0cwb9p6sUwid6bQhvQd6pfwQAVlA4ICgAAABwAQCdASoIAAgAAkA4JaACdAFAAAD+7QcSMNGv/zBP/f7/v95LgAAA","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/Admission/cross.webp
/* harmony default export */ const cross = ({"src":"/_next/static/media/cross.a1bdf5d9.webp","height":240,"width":240,"blurDataURL":"data:image/webp;base64,UklGRogAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSDwAAAABV6CojRQ4tif88EtEBMjjcl6EothWquG/JQIx1AQuiUAEOmgDI1g6ov8Bgd5alusLnhF4d9R82pIGgQ5WUDggJgAAAHABAJ0BKggACAACQDgloAJ0AXUAAP7tBxF2j/8pX/xu/3ZcwgAA","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./pages/_app.js





// import 'tw-elements';

const Footer = dynamic_default()(()=>Promise.all(/* import() */[__webpack_require__.e(993), __webpack_require__.e(494), __webpack_require__.e(13)]).then(__webpack_require__.bind(__webpack_require__, 9013)), {
    loadableGenerated: {
        modules: [
            "_app.js -> " + "../components/FooterComponents/Footer"
        ]
    },
    ssr: false
});




// import Footer from "../components/FooterComponents/Footer";
// import Head from 'next/head'


function MyApp({ Component , pageProps  }) {
    (0,external_react_.useEffect)(()=>{
        const use = async ()=>{
            (await Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 2727, 23))).default;
        };
        use();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "fb-root"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "fb-customer-chat",
                className: "fb-customerchat"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "one",
                strategy: "afterInteractive",
                src: "https://www.googletagmanager.com/gtag/js?id=UA-235343232-1",
                defer: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "three",
                strategy: "afterInteractive",
                dangerouslySetInnerHTML: {
                    __html: `
         window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());
        gtag('config', 'UA-235343232-1');
        `
                },
                defer: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "four",
                strategy: "afterInteractive",
                dangerouslySetInnerHTML: {
                    __html: `
         (function (w, d, s, l, i) {
          w[l] = w[l] || []; w[l].push({
            'gtm.start':
          new Date().getTime(), event: 'gtm.js'
          }); var f = d.getElementsByTagName(s)[0],
          j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
          'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-MSWM9SX');
        `
                },
                defer: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "six",
                strategy: "afterInteractive",
                dangerouslySetInnerHTML: {
                    __html: `
                 !function (f, b, e, v, n, t, s) {
                if (f.fbq) return; n = f.fbq = function () {
                  n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                };
                if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = '2.0';
                n.queue = []; t = b.createElement(e); t.async = !0;
                t.src = v; s = b.getElementsByTagName(e)[0];
                s.parentNode.insertBefore(t, s)
              }(window, document, 'script',
                'https://connect.facebook.net/en_US/fbevents.js');
              fbq('init', '625661268931680');
              fbq('track', 'PageView');
        `
                },
                defer: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "seven",
                strategy: "afterInteractive",
                dangerouslySetInnerHTML: {
                    __html: `
                var chatbox = document.getElementById('fb-customer-chat');
                chatbox.setAttribute("page_id", "102190078089641");
                chatbox.setAttribute("attribution", "biz_inbox");
        `
                },
                defer: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "eight",
                strategy: "afterInteractive",
                dangerouslySetInnerHTML: {
                    __html: `
                window.fbAsyncInit = function () {
                FB.init({
                  xfbml: true,
                  version: 'v15.0'
                });
              };

              (function(d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s); js.id = id;
                js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
                fjs.parentNode.insertBefore(js, fjs);
              }(document, 'script', 'facebook-jssdk'));
        `
                },
                defer: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "admission-modal",
                id: "admission-modal",
                style: {
                    width: "100%",
                    height: "100vh",
                    backgroundColor: "rgba(0,0,0,0.6)",
                    overflow: "hidden",
                    justifyContent: "center",
                    alignItems: "center"
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    id: "admission-modal-box",
                    style: {
                        borderRadius: "15px",
                        width: "50%",
                        marginRight: "auto",
                        marginLeft: "auto",
                        background: "white",
                        padding: "20px",
                        textAlign: "center",
                        position: "relative"
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: checked,
                            alt: "check-icon",
                            height: 80,
                            width: 80,
                            style: {
                                display: "inline",
                                marginTop: "1.8em"
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: cross,
                            alt: "cross-icon",
                            id: "cross-icon",
                            height: 32,
                            width: 32,
                            style: {
                                display: "inline",
                                position: "absolute",
                                top: "10px",
                                right: "10px",
                                cursor: "pointer"
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            style: {
                                padding: " 0.8em 1em 0",
                                color: "inherit",
                                fontSize: " 1.875em",
                                fontWeight: " 600",
                                textAlign: " center",
                                textTransform: " none",
                                wordWrap: " break-word"
                            },
                            children: "Thank You"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            style: {
                                padding: " 0.8em 1em",
                                color: "inherit",
                                fontSize: " 1.125em",
                                fontWeight: " 600",
                                textAlign: " center",
                                textTransform: " none",
                                wordWrap: " break-word"
                            },
                            children: "We will get back to you soon."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/courses",
                            type: "button",
                            className: "bg-green-500 rounded-lg h-10 px-5 text-md bg-green-500 text-white",
                            style: {
                                margin: "0.3125em",
                                padding: "0.625em 1.1em",
                                transition: "box-shadow .1s",
                                boxShadow: "0 0 0 3px rgb(0 0 0 / 0%)",
                                fontWeight: "500",
                                color: "white"
                            },
                            children: " View Courses ! "
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                            className: " mt-2 mb-2"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/courses",
                            className: "text-green-500 underline",
                            style: {
                                textUnderlinePosition: "under"
                            },
                            children: "Home"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "nine",
                strategy: "afterInteractive",
                dangerouslySetInnerHTML: {
                    __html: `
        document.getElementById("admission-modal").addEventListener("click",()=>{
          document.getElementById("admission-modal").classList.remove("active")
        })
        document.getElementById("cross-icon").addEventListener("click",()=>{
          document.getElementById("admission-modal").classList.remove("active")
        })
        document.getElementById("admission-modal-box").addEventListener("click",(event)=>{
          event.stopPropagation();

        })
       
        `
                },
                defer: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                id: "scroll-to-top",
                className: "bg-green-500",
                onClick: ()=>{
                    window.scroll(0, 0);
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 448 512",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M246.6 41.4c-12.5-12.5-32.8-12.5-45.3 0l-160 160c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L224 109.3 361.4 246.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-160-160zm160 352l-160-160c-12.5-12.5-32.8-12.5-45.3 0l-160 160c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L224 301.3 361.4 438.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3z"
                    })
                })
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 3790:
/***/ (() => {



/***/ }),

/***/ 2675:
/***/ (() => {



/***/ }),

/***/ 9517:
/***/ (() => {



/***/ }),

/***/ 8089:
/***/ (() => {



/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(3573)


/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2727:
/***/ ((module) => {

"use strict";
module.exports = require("tw-elements");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,676,61,152], () => (__webpack_exec__(5176)));
module.exports = __webpack_exports__;

})();