"use strict";
(() => {
var exports = {};
exports.id = 355;
exports.ids = [355];
exports.modules = {

/***/ 8232:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Loader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/loading.svg
/* harmony default export */ const loading = ({"src":"/_next/static/media/loading.5814c667.svg","height":51,"width":51});
;// CONCATENATED MODULE: ./components/Loader.jsx



const Loader = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "h-screen w-screen flex items-center justify-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: loading,
            alt: "spinner"
        })
    });
};
/* harmony default export */ const components_Loader = (Loader);


/***/ }),

/***/ 728:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ useWindowSize)
/* harmony export */ });
function useWindowSize(props) {
    const [windowSize, setWindowSize] = props?.useState({
        width: undefined,
        height: undefined
    });
    props?.useEffect(()=>{
        function handleResize() {
            setWindowSize({
                width: window.innerWidth,
                height: window.innerHeight
            });
        }
        window.addEventListener("resize", handleResize);
        handleResize();
        return ()=>window.removeEventListener("resize", handleResize);
    }, []);
    return windowSize;
}


/***/ }),

/***/ 7784:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8232);
/* harmony import */ var _TrainingBanner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2465);
/* harmony import */ var _TrainingComponents_RelatedComponents__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3599);
/* harmony import */ var _TrainingContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4756);
/* harmony import */ var _TrainingSubHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6519);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_TrainingComponents_RelatedComponents__WEBPACK_IMPORTED_MODULE_5__, _TrainingContainer__WEBPACK_IMPORTED_MODULE_6__]);
([_TrainingComponents_RelatedComponents__WEBPACK_IMPORTED_MODULE_5__, _TrainingContainer__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Training = (props)=>{
    const HomeSuccessStories = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(()=>__webpack_require__.e(/* import() */ 672).then(__webpack_require__.bind(__webpack_require__, 523)), {
        loadableGenerated: {
            modules: [
                "..\\components\\TrainingComponents\\Training.jsx -> " + "../../components/HomePageComponents/HomeSuccessStories"
            ]
        },
        ssr: false
    });
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    let meta_description = props?.course?.data?.meta?.find((meta)=>meta.name == "description")?.content || "";
    let meta_image = props?.course?.data?.course[0]?.banner;
    if (meta_image) {
        meta_image = `${"https://mindrisers.com.np"}${meta_image}`;
    }
    let current_url = `${"https://www.mindrisers.com.np"}${router.asPath}`;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: props?.course?.data?.course[0]?.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "title",
                        content: props?.course?.data?.course[0]?.title
                    }),
                    props?.course?.data?.meta?.map((meta)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            name: meta?.name,
                            content: meta?.content,
                            detail: meta?.detail,
                            property: meta?.property
                        }, meta?.id);
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:url",
                        content: current_url
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:type",
                        content: "website"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:title",
                        content: props?.course?.data?.course[0]?.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:description",
                        content: meta_description
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image",
                        content: meta_image
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:card",
                        content: "summary"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:site",
                        content: "@mindrisers"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:creator",
                        content: "@mindrisers"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "twitter:title",
                        content: props?.course?.data?.course[0]?.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "twitter:description",
                        content: meta_description
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:image",
                        content: meta_image
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: props?.course ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TrainingBanner__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            course: props?.course
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TrainingSubHeader__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "lg:px-44 md:px-20 px-6 sm:px-16",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TrainingContainer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    course: props?.course,
                                    course_list: props?.course_list,
                                    course_id: props?.course_id
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HomeSuccessStories, {
                                    in_training_page: true,
                                    successStoreis: props?.success_stories
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TrainingComponents_RelatedComponents__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    course: props?.course
                                })
                            ]
                        })
                    ]
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Training);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ScreenSize__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(728);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);





const TrainingBanner = (props)=>{
    const size = (0,_ScreenSize__WEBPACK_IMPORTED_MODULE_4__/* .useWindowSize */ .i)({
        useEffect: react__WEBPACK_IMPORTED_MODULE_2__.useEffect,
        useState: react__WEBPACK_IMPORTED_MODULE_2__.useState
    });
    const course = props?.course?.data?.course[0];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "overflow-hidden",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: " bg-center bg-cover bg-no-repeat text-md training-banner relative ",
            style: {
                // backgroundImage: `url("https://mindrisers.com.np${size?.width < 600 ? course?.mobile_banner : course?.banner}")`,
                backgroundSize: "cover",
                backgroundPosition: "center",
                backgroundColor: "rgba(0,0,0,0.75)",
                backgroundBlendMode: "darken",
                backgroundRepeat: "no-repeat",
                position: "relative"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    width: 1500,
                    height: 1500,
                    src: `https://mindrisers.com.np${size?.width < 600 ? course?.mobile_banner : course?.banner}`,
                    style: {
                        position: "fixed",
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                        zIndex: "-1",
                        filter: "brightness(30%)"
                    },
                    alt: course?.title
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "text-white text-right flex flex-col items-end gap-8 lg:p-16 sm:p-12 p-6",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/",
                                    children: "Home"
                                }),
                                " / ",
                                course?.title
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: " text-3xl ",
                            children: course?.title
                        }),
                        course?.banner_desc && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "",
                            children: course?.banner_desc
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex text-right flex-col",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "",
                                    children: [
                                        "Duration: ",
                                        course?.duration
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "",
                                    children: [
                                        "Career: ",
                                        course?.career
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex gap-8 justify-end",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    className: "bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 border border-green-600 rounded fill-white flex gap-2 items-center text-sm",
                                    href: "#quick_inquiry",
                                    scroll: false,
                                    children: [
                                        "Send Enquiry",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 512 512",
                                            className: "w-3",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/online-admission",
                                    className: "bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 border border-green-600 rounded fill-white flex gap-2 items-center text-sm",
                                    children: [
                                        "Get Admission",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 448 512",
                                            className: "w-3",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M438.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L338.8 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l306.7 0L233.4 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TrainingBanner);


/***/ }),

/***/ 3599:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2494);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_4__]);
_pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const RelatedComponents = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const pathname = router.pathname.split("/")[1];
    const { slug  } = router.query;
    const [courses, setCourses] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    // const ApiType = pathname == "courses" ? 6 : 7
    // const ApiType = pathname == "courses" ? 6 : 7
    const ApiType = null;
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        (0,_pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_4__/* .coursesApi */ .Ni)({
            setCourses,
            ApiType
        });
    }, []);
    return(// <div className="lg:px-18 md:px-14 px-6 sm:flex-col flex-col flex gap-10 mb-10 mt-10">
    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: " sm:flex-col flex-col flex gap-10 mb-10 mt-10",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold text-3xl",
                        children: "Related Courses"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "grid gap-2 mt-4 overflow-auto grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
                        children: courses?.slice(0, 7)?.map((course)=>{
                            return !(slug == course.slug) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                className: "flex gap-1 items-center truncate",
                                href: `/${pathname == "courses" ? "courses" : "after+2-courses"}/${course.slug}`,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        width: 450,
                                        height: 450,
                                        src: `${"https://mindrisers.com.np/"}${course.image}`,
                                        className: "w-20",
                                        alt: `${course.slug}`
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "whitespace-nowrap truncate overflow-hidden",
                                        children: course.title
                                    })
                                ]
                            }, course.id);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold text-3xl",
                        children: "Browse by tags."
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-3 flex-wrap mt-4",
                        style: {
                            color: "blue"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "cursor-pointer",
                                children: "#PHP"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "cursor-pointer",
                                children: "#Vue.Js Career"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "cursor-pointer",
                                children: "#Web Development"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "cursor-pointer",
                                children: "#MERN"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RelatedComponents);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ TrainingComponents_TrainingOverview)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./assets/icons/iconmonstr-arrow-down-thin-48-_1_.webp
/* harmony default export */ const iconmonstr_arrow_down_thin_48_1_ = ({"src":"/_next/static/media/iconmonstr-arrow-down-thin-48-_1_.3185e6ba.webp","height":48,"width":48,"blurDataURL":"data:image/webp;base64,UklGRnQAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSDUAAAABYBTbdpObIiCrSmfNMg7oCAARMYPnpiEiAsnUIfhRjwSYehBYlgoDY0rFWSI4ch5QAu4LDQBWUDggGAAAADABAJ0BKggACAACQDglpAADcAD++5zAAA==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/icons/iconmonstr-arrow-up-thin-48-_1_.webp
/* harmony default export */ const iconmonstr_arrow_up_thin_48_1_ = ({"src":"/_next/static/media/iconmonstr-arrow-up-thin-48-_1_.405eb5c8.webp","height":48,"width":48,"blurDataURL":"data:image/webp;base64,UklGRnQAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSDYAAAABYBvZtpLzpYKfKRaRWwFO7k1AI5TN0ENEBIJ3RSNYnrtE0bVVuBxYpogBGAoQKIYcCfITfwBWUDggGAAAADABAJ0BKggACAACQDglpAADcAD++5zAAA==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/TrainingComponents/TrainingComponents/TrainingOverview.jsx
// import sanitizeHtml from 'sanitize-html';
/* 
 display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 3;
    overflow: hidden;
    scrollbar-width: none;
*/ 




let first_page_load = false;
const TrainingOverview = (props)=>{
    const [limitOverView, setlimitOverView] = (0,external_react_.useState)(true);
    (0,external_react_.useEffect)(()=>{
        if (limitOverView && first_page_load) {
            setTimeout(()=>{
                // Get the navigation bar element
                const navbar = document.getElementById("navbar--sticky");
                // Get the element to scroll to
                const syllabus = document.getElementById("course_syllabus");
                // Get the offset position of the element to scroll to
                const syllabusOffset = syllabus.offsetTop;
                // Get the height of the navigation bar element
                const navbarHeight = navbar.offsetHeight;
                // Calculate the final position to scroll to
                const finalPosition = syllabusOffset - navbarHeight - 40;
                // Scroll to the final position
                window.scrollTo({
                    top: finalPosition,
                    behavior: "smooth"
                });
            }, 100);
        } else {
            first_page_load = true;
        }
    }, [
        limitOverView
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "course_overview",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "font-bold",
                children: props?.course?.data?.course[0]?.title
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `overview__wrapper relative ${limitOverView ? "limited" : ""}`,
                style: {},
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: props?.course?.data?.course[0]?.description
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "fader absolute"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "m-8 text-center font-bold",
                id: "overview__min_max",
                style: {
                    cursor: "pointer",
                    textTransform: "uppercase"
                },
                onClick: ()=>{
                    setlimitOverView(!limitOverView);
                },
                children: limitOverView ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    alt: "arrow-down-icon",
                                    src: iconmonstr_arrow_down_thin_48_1_,
                                    height: 16,
                                    width: 16,
                                    className: "inline"
                                }),
                                "  "
                            ]
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "inline",
                            children: "Read More"
                        })
                    ]
                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    alt: "arrow-up-icon",
                                    src: iconmonstr_arrow_up_thin_48_1_,
                                    height: 16,
                                    width: 16,
                                    className: "inline"
                                }),
                                "  "
                            ]
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "inline",
                            children: "Read Less"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const TrainingComponents_TrainingOverview = (TrainingOverview);


/***/ }),

/***/ 9239:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ TrainingComponents_TrainingSyllabus)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/TrainingComponents/TrainingComponents/TrainingAccordion.jsx
// import sanitizeHtml from 'sanitize-html';

const TrainingAccordion = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "accordion-tabs",
        children: props?.syllabus?.map((syllable)=>{
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "accordion-tab",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "checkbox",
                        id: syllable.id
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        className: "accordion-tab-label",
                        htmlFor: syllable.id,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            children: syllable.heading
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "accordion-tab-content text-left",
                        dangerouslySetInnerHTML: {
                            __html: (syllable?.description)
                        }
                    })
                ]
            }, syllable.id);
        })
    });
};
/* harmony default export */ const TrainingComponents_TrainingAccordion = (TrainingAccordion);

;// CONCATENATED MODULE: ./components/TrainingComponents/TrainingComponents/TrainingSyllabus.jsx


const TrainingSyllabus = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: props?.course?.data?.syllabus[0] && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " mt-10",
            id: "course_syllabus",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                    className: "font-bold",
                    children: [
                        "Syllabus of ",
                        props?.course?.data?.course[0].title
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: "my-2"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(TrainingComponents_TrainingAccordion, {
                    syllabus: props?.course?.data?.syllabus
                })
            ]
        })
    });
};
/* harmony default export */ const TrainingComponents_TrainingSyllabus = (TrainingSyllabus);


/***/ }),

/***/ 4756:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _TrainingComponents_TrainingOverview__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4773);
/* harmony import */ var _TrainingComponents_TrainingSyllabus__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9239);
/* harmony import */ var _TrainingInquiry__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1218);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_TrainingInquiry__WEBPACK_IMPORTED_MODULE_4__]);
_TrainingInquiry__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const TrainingContainer = (props)=>{
    const date = props?.course?.data?.time;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                // className='flex gap-5 mt-20 p-6 lg:px-18 overflow-auto px-8 sm:px-12 md:px-14 lg:px-18 '
                // className='flex gap-5 mt-20 py-6 lg:px-18 overflow-auto  '
                className: "flex gap-5 py-6 overflow-auto ",
                style: {
                    borderBottom: "0.5px solid rgb(163 163 163)"
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "#course_overview",
                        className: "training-indicator",
                        scroll: false,
                        children: [
                            "Course Overview",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "0 0 448 512",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M246.6 470.6c-12.5 12.5-32.8 12.5-45.3 0l-160-160c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L224 402.7 361.4 265.4c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3l-160 160zm160-352l-160 160c-12.5 12.5-32.8 12.5-45.3 0l-160-160c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L224 210.7 361.4 73.4c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3z"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "#course_syllabus",
                        className: "training-indicator",
                        scroll: false,
                        children: [
                            "Course Syllabus",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "0 0 448 512",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M246.6 470.6c-12.5 12.5-32.8 12.5-45.3 0l-160-160c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L224 402.7 361.4 265.4c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3l-160 160zm160-352l-160 160c-12.5 12.5-32.8 12.5-45.3 0l-160-160c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L224 210.7 361.4 73.4c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3z"
                                })
                            })
                        ]
                    }),
                    props?.course?.data?.success_story[0] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "#success_stories",
                        className: "training-indicator",
                        scroll: false,
                        children: [
                            "Success Stories",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "0 0 448 512",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M246.6 470.6c-12.5 12.5-32.8 12.5-45.3 0l-160-160c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L224 402.7 361.4 265.4c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3l-160 160zm160-352l-160 160c-12.5 12.5-32.8 12.5-45.3 0l-160-160c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L224 210.7 361.4 73.4c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3z"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex gap-6 justify-center flex-wrap lg:flex-nowrap ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-[60%] mt-10 text-justify flex-grow",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TrainingComponents_TrainingOverview__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                course: props.course
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TrainingComponents_TrainingSyllabus__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                course: props.course
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-grow",
                        children: [
                            date && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "bg-green-500 flex flex-wrap w-full p-5 justify-between text-white ",
                                children: date?.map((item)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex w-full justify-between",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "whitespace-nowrap",
                                                children: item?.start_date
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "whitespace-nowrap",
                                                children: item?.start_time
                                            })
                                        ]
                                    }, item.id);
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TrainingInquiry__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                course: props.course,
                                course_list: props.course_list,
                                course_id: props?.course_id
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TrainingContainer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1218:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2494);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_4__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const TrainingInquiry = (props)=>{
    const { register , handleSubmit , formState: { errors  } , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const [submiting, setSubmiting] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const onSubmit = (data)=>{
        setSubmiting(true);
        (0,_pages_api_apiCalls__WEBPACK_IMPORTED_MODULE_4__/* .ContactListApi */ .vE)({
            setSubmiting,
            data,
            reset,
            router
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        style: {
            position: "sticky",
            top: "100px"
        },
        className: "bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4 w-full mt-5 form",
        id: "quick_inquiry",
        onSubmit: handleSubmit(onSubmit),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "block text-lg font-bold mb-2",
                children: "Quick Inquiry"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: "block text-sm font-bold mb-2",
                        htmlFor: "username",
                        children: "Name *"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: "shadow appearance-none border rounded w-full py-2 px-3 leading-tight focus:outline-none focus:shadow-outline",
                        placeholder: "Name",
                        name: "name",
                        ...register("name", {
                            required: true
                        })
                    }),
                    errors?.name?.type === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "This field is required"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: "block text-sm font-bold mb-2",
                        htmlFor: "username",
                        children: "Email *"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: "shadow appearance-none border rounded w-full py-2 px-3 leading-tight focus:outline-none focus:shadow-outline",
                        placeholder: "Email",
                        name: "email",
                        ...register("email", {
                            required: true,
                            pattern: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
                        })
                    }),
                    errors?.email?.type === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "This field is required"
                    }),
                    errors?.email?.type === "pattern" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Invalid Email"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: "block text-sm font-bold mb-2",
                        htmlFor: "username",
                        children: "Mobile Number *"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: "shadow appearance-none border rounded w-full py-2 px-3 leading-tight focus:outline-none focus:shadow-outline",
                        type: "number",
                        placeholder: "Mobile Number",
                        name: "mobile_no",
                        ...register("mobile_no", {
                            required: true
                        })
                    }),
                    errors?.mobile_no?.type === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "This field is required"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: "block text-sm font-bold mb-2",
                        htmlFor: "username",
                        children: "Alternate Number"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: "shadow appearance-none border rounded w-full py-2 px-3 leading-tight focus:outline-none focus:shadow-outline",
                        type: "number",
                        placeholder: "Alternate Number",
                        name: "alternate_number",
                        ...register("alternate_number")
                    }),
                    errors?.alternate_number?.type === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "This field is required"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: "block text-sm font-bold mb-2",
                        htmlFor: "username",
                        children: "Subject"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: "shadow appearance-none border rounded w-full py-2 px-3 leading-tight focus:outline-none focus:shadow-outline",
                        type: "text",
                        placeholder: "Subject",
                        name: "subject",
                        ...register("subject")
                    }),
                    errors?.subject?.type === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "This field is required"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: "block text-sm font-bold mb-2",
                        htmlFor: "username",
                        children: "Selected Course"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                        className: "shadow appearance-none border rounded w-full py-2 px-3 leading-tight focus:outline-none focus:shadow-outline",
                        placeholder: "Selected Course",
                        name: "select_course",
                        ...register("select_course"),
                        children: props.course_list.map((el)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: el.id,
                                selected: props?.course_id == el.slug,
                                children: el.title
                            }, el.id);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: "block text-sm font-bold mb-2",
                        htmlFor: "username",
                        children: "Message"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                        className: "shadow appearance-none border rounded w-full py-2 px-3 leading-tight focus:outline-none focus:shadow-outline",
                        type: "text",
                        placeholder: "Message",
                        name: "message",
                        ...register("message")
                    }),
                    errors?.message?.type === "required" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "This field is required"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex items-center justify-between",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    type: "submit",
                    name: "name",
                    className: "px-4 py-2 text-lg font-medium text-white duration-500 bg-green-500 rounded-md cursor-pointer hover:bg-slate-400 hover:text-black w-max",
                    disabled: submiting,
                    children: submiting ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-center items-center gap-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "spinner-border animate-spin inline-block w-5 h-5 border-4 rounded-full",
                                role: "status",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "visually-hidden",
                                    children: "Loading..."
                                })
                            }),
                            "Submit Enquiry"
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: "Submit Enquiry"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TrainingInquiry);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6519:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ TrainingComponents_TrainingSubHeader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/trainingIcons/1-min.png
/* harmony default export */ const _1_min = ({"src":"/_next/static/media/1-min.c4dec7f4.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAdVBMVEUAg0MAg0IAgkMAgkIAg0MAg0IAg0MAg0IAgkMAg0IAg0MAg0IAg0MAg0MAgkMAg0IAgkMAg0MAg0MAgkMAg0IAg0IAg0MAgkIAgkIAg0MAg0MAg0MAgkIAgkIAg0MAg0MAg0MAg0MAg0MAgkMAg0MAg0IAgkJA/G/7AAAAJHRSTlMAAAAAAQECAgIEBwkLDxgZICMkJCgwPD10fsDHx8nL2tzf/PzMvoYHAAAAR0lEQVR42g3ExwGAMAwEsHMcQu+9gwnef0TQQwitI4oCBwbixPyPOS8HZQOme3v9fs2oVEXU9+BVH9EzBYquqdsSsIYAJvsBiCoEBrH5ZfUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/trainingIcons/3-min.png
/* harmony default export */ const _3_min = ({"src":"/_next/static/media/3-min.fe98ea30.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAaVBMVEUAg0MAg0IAgkMAgkIAg0MAg0IAgkIAg0MAgkMAgkIAg0MAg0IAgkMAg0IAgkIAg0MAgkMAgkIAgkIAgkIAgkIAg0MAg0MAg0MAg0MAgkIAg0MAg0IAg0MAgkMAg0MAg0MAg0IAg0MAg0OXHu2nAAAAInRSTlMAAAAAAQEBAgICAwMDBAYICCIkRUhSVX+Ck5bHyc/T5+v8iujoRwAAAERJREFUeNoNxkcSgCAQAMEhKIqCOef9/yPl0tVkOh5nS47yelkTaKeum8JgTXzeRlkc3Se9KglmEpkJeAaRkYq0bafWP22gAzJlOOvWAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/trainingIcons/Untitled-2-min.png
/* harmony default export */ const Untitled_2_min = ({"src":"/_next/static/media/Untitled-2-min.e25a1333.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAApklEQVR42i2LrQ7CMBhFL7jNbPyEAAZB8CzgSVpHsMjtCQjBg4DVAwpeBuy2B5rfTpM1Ob33O/0qOSPYy9kRJMrNFgLImPv+cUVZk0dkRRZkituRS3ElDHPlNoWSuWDOWJySGyEjygkmPD7hTR/DgR6L0mNpRgqGyIgM5MxC/iA8IXKAvNJv9BjCbsF+kDU0yAt57noNX/HrR3khS/LBh7t8986Zfwu2EEWAR2FnjAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./components/TrainingComponents/TrainingSubHeader.jsx





const TrainingSubHeader = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-slate-50 flex justify-around items-center lg:px-44 md:px-20 px-2 text-green-500",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "training-icon-div",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: _1_min,
                        alt: "learn-with-us"
                    }),
                    "Learn with us"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "training-icon-div",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: Untitled_2_min,
                        alt: "sharpen-your-skills"
                    }),
                    "Sharpen your skills"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "training-icon-div",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: _3_min,
                        alt: "grab-a-guaranteed-internship"
                    }),
                    "Grab a Guaranteed Internship"
                ]
            })
        ]
    });
};
/* harmony default export */ const TrainingComponents_TrainingSubHeader = (TrainingSubHeader);


/***/ }),

/***/ 6039:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ course),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_HeaderComponents_Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8435);
/* harmony import */ var _components_TrainingComponents_Training__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7784);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_TrainingComponents_Training__WEBPACK_IMPORTED_MODULE_2__]);
_components_TrainingComponents_Training__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



async function getStaticPaths() {
    const res = await fetch(`${"https://mindrisers.com.np/blog/api/v1/"}course/`);
    const courses = await res.json();
    const paths = courses?.map((course)=>({
            params: {
                slug: course.slug
            }
        }));
    return {
        paths,
        fallback: "blocking"
    };
}
// `getStaticPaths` requires using `getStaticProps`
async function getStaticProps({ params  }) {
    const res = await fetch(`${"https://mindrisers.com.np/blog/api/v1/"}coursecombine/${params.slug}/`);
    if (!res.ok) {
        return {
            notFound: true
        };
    }
    const course = await res.json();
    const data = await fetch(`${"https://mindrisers.com.np/blog/api/v1/"}course/`);
    const course_list = await data.json();
    const success_storie_res = await fetch(`${"https://mindrisers.com.np/blog/api/v1/"}successstoryhome/`);
    const success_stories = await success_storie_res.json();
    return {
        props: {
            course,
            course_list,
            course_id: params.slug,
            success_stories
        },
        revalidate: 60 * 60 * 24 * 1 // this may cause server unndecessary loads, since the data merely gets changed. but it is definately better than SSR ?  SSR doesnot trigger the html and store it  while ISR does -> ISR > SSR cause SSR will also create load on server since, every time, the server needs to create html and send as response while ISR will simply cache it and set it. 
    };
}
// This also gets called at build time
// export async function getServerSideProps({ params }) {
//     const res = await fetch(`${process.env.DOMAIN_V1}coursecombine/${params.slug}/`)
//     const course = await res.json()
//     const data = await fetch(`${process.env.DOMAIN_V1}course/`)
//     const course_list = await data.json()
//     return { props: { course, course_list, course_id: params.slug } }
// }
// This also gets called at build time
// export async function getServerSideProps({ params }) {
//     const res = await fetch(`${process.env.DOMAIN_V1}coursecombine/${params.slug}/`)
//     const course = await res.json()
//     const data = await fetch(`${process.env.DOMAIN_V1}course/`)
//     const course_list = await data.json()
//     return { props: { course, course_list, course_id: params.slug } }
// }
function course(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_HeaderComponents_Header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_TrainingComponents_Training__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    ...props
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,676,61,152,993,435,494], () => (__webpack_exec__(6039)));
module.exports = __webpack_exports__;

})();